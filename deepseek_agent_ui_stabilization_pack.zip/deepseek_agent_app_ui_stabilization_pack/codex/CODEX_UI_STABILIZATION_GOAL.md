# Codex Goal — Stabilize DeepSeek Agent macOS UI/UX

## Goal

Turn the current visually mocked DeepSeek Agent macOS prototype into a tested, clickable, production-feeling MVP UI.

The target is not only better colors. The target is a usable app:

- no confusing Keychain password prompt;
- no fake macOS window chrome inside content;
- no blue/purple background bleed inside the real app window;
- all visible controls either work or have clear disabled states;
- no blank diff/review area on a new chat;
- Settings and runtime states are internally consistent;
- demo mode can be launched and tested without a DeepSeek API key;
- UI remains responsive while fake runtime events stream.

## Architecture decision

Prefer a macOS-native hybrid:

- SwiftUI/AppKit for shell, sidebar, settings, onboarding, menus, keychain, sidecar lifecycle, file picker, shortcuts, and system UI.
- Optional WKWebView/React only for thread timeline, diff/code review, terminal output, and rich markdown.
- DeepSeek-TUI remains the sidecar runtime.

If the current implementation is fully React/WebView, do not rewrite everything immediately. First stabilize the existing UI, then extract shell pieces to native SwiftUI/AppKit in small steps.

## Reference docs

Read these first:

- `docs/01_TECH_STACK_DECISION.md`
- `docs/02_BUGFIX_SPEC.md`
- `docs/03_KEYCHAIN_FIX.md`
- `docs/04_LAYOUT_AND_VISUAL_FIX.md`
- `docs/05_INTERACTION_TEST_MATRIX.md`
- `docs/06_PERFORMANCE_PLAN.md`
- `docs/09_ACCEPTANCE_CHECKLIST.md`

Use visual references:

- `references/target_mockups/01_active_thread_codex_inspired.png`
- `references/target_mockups/02_first_run_setup_codex_inspired.png`
- `references/target_mockups/03_project_command_center_codex_inspired.png`
- `references/target_mockups/04_review_changes_codex_inspired.png`
- `references/target_mockups/05_settings_usage_codex_inspired.png`

Use current issue screenshots:

- `references/observed/01_keychain_prompt.png`
- `references/observed/02_review_empty_state_layout.png`
- `references/observed/03_settings_interaction_state.png`

## Required work

### 1. Diagnose implementation

Find out whether the app is:

- full SwiftUI;
- Swift shell + WKWebView;
- full web UI inside WebView;
- another architecture.

Record findings in `docs/IMPLEMENTATION_PROGRESS.md`.

### 2. Remove Keychain system prompt

Implement `docs/03_KEYCHAIN_FIX.md`.

Acceptance: system Keychain password dialog does not appear during launch, settings load, key save, key rotate, or key delete.

### 3. Fix shell and layout

Implement `docs/04_LAYOUT_AND_VISUAL_FIX.md`.

Acceptance:

- no fake traffic lights inside content;
- no large blue background bleed inside the window;
- new chat screen shows starter prompts, not a blank diff view;
- review screen has a valid no-changes state.

### 4. Make interactions real

Implement the matrix in `docs/05_INTERACTION_TEST_MATRIX.md`.

Acceptance: every visible control is functional or explicitly disabled with a clear reason.

### 5. Improve performance

Implement `docs/06_PERFORMANCE_PLAN.md`.

Acceptance:

- composer typing is responsive;
- fake event stream is batched;
- diff/code viewer is not rendered when empty;
- route switches do not visibly lag.

### 6. Test and document

Create/update:

- `docs/IMPLEMENTATION_PROGRESS.md`
- `docs/UI_QA_RESULTS.md`
- `docs/KNOWN_ISSUES.md`

Run the project’s actual build/test commands. If tests do not exist, add minimal smoke tests or a QA script.

## Validation loop

Do not stop after a visual-only pass. Keep iterating until every item in `docs/09_ACCEPTANCE_CHECKLIST.md` passes, or stop with a precise blocker and command output.

