# UI QA Instructions for Codex

## Product constraints

- This is a macOS-only DeepSeek Agent app.
- DeepSeek-TUI remains the runtime sidecar.
- Do not reimplement DeepSeek-TUI runtime.
- Do not fork OpenBridge or Codex.
- Do not use OpenAI/Codex model names in the app UI.
- Use DeepSeek-only model names: `deepseek-v4-flash`, `deepseek-v4-pro`.

## UX constraints

- Do not draw fake macOS traffic lights inside web content.
- Do not show a system Keychain password prompt during normal app use.
- Do not show active primary actions that cannot succeed.
- Do not use a large marketing gradient as the app’s internal production background.
- Every button must either work or be visibly disabled with a reason.

## Testing constraints

Before saying the task is complete, run the actual build and test commands. If the repo has no tests, create minimal tests or a documented manual QA checklist and execute it.

Always update:

- `docs/IMPLEMENTATION_PROGRESS.md`
- `docs/UI_QA_RESULTS.md`
- `docs/KNOWN_ISSUES.md`

## Performance constraints

- Batch streaming events.
- Avoid full-app re-render per token/event.
- Avoid rendering diff/code viewer when no file is selected.
- Keep composer typing responsive.

