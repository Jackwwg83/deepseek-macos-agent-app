# 02 — Bugfix Spec From Current Screenshots

## Observed issue A — Keychain password prompt appears

Screenshot: `references/observed/01_keychain_prompt.png`

### User impact

The dialog says the app wants to use confidential information from `app.deepseek.agent` in the login keychain. This is confusing and alarming. Users may think the app is trying to access system secrets.

### Expected behavior

- First run: show a custom in-app API key form.
- Save: store the API key silently in macOS Keychain.
- Normal launch: read the key silently if available.
- If key access fails: show an in-app error and offer to re-enter the key.
- Never show the macOS login-keychain password dialog during normal app use.

### Acceptance check

Launch the app on a clean local account or after clearing the app keychain item. The system Keychain password prompt must not appear.

---

## Observed issue B — blue/purple background leaks around content

Screenshot: `references/observed/02_review_empty_state_layout.png`

### Diagnosis

The mockup-style gradient appears to be implemented as the app/root background and remains visible inside the actual app window. In a production macOS app this makes the window look like a screenshot pasted onto a wallpaper rather than a native application.

### Expected behavior

- Use the real macOS window background.
- Use a subtle material/translucent effect only in the sidebar if desired.
- Main content and right inspector should fill the app content area edge-to-edge.
- A promotional gradient is acceptable in marketing mockups, but not as a large visible inner margin in the running app.

### Required fix

Remove any top-level CSS gradient/background from the production app root. If React is still used, ensure:

```css
html, body, #root {
  width: 100%;
  height: 100%;
  margin: 0;
  overflow: hidden;
  background: transparent; /* or a neutral app background, not marketing gradient */
}

.app-shell {
  width: 100vw;
  height: 100vh;
  display: grid;
  grid-template-columns: 320px minmax(0, 1fr) 320px;
  background: var(--app-background);
}
```

In a native shell, the SwiftUI root view must occupy the full window using `NavigationSplitView` or explicit full-frame layout.

---

## Observed issue C — controls look clickable but do not work

Screenshots: `references/observed/02_review_empty_state_layout.png`, `references/observed/03_settings_interaction_state.png`

### User impact

Users cannot tell whether a control is disabled, missing a handler, blocked by runtime state, or broken.

### Expected behavior

Every control must be in one of three states:

1. **Active** — clicking performs the action.
2. **Disabled with reason** — visually disabled and has tooltip/help text.
3. **Hidden** — not shown until the feature is available.

### Required fixes

- `New thread`: always active.
- `Review changes`: active if there are changed files; otherwise shows empty review state with explanation.
- `Open in editor`: disabled when no file/project is selected; tooltip: “Select a file or project first.”
- `Apply selected`, `Reject selected`, `Commit 0 files`: disabled when no files are selected.
- `Request more tests`: active only when runtime is available; otherwise shows “Start runtime first.”
- `Manage account`: opens native settings or account sheet.
- `Rotate key`: opens re-enter API key sheet.
- Model dropdown: must actually change stored model preference.
- Toggles: update settings state and persist.

### Acceptance check

Run the click matrix in `docs/05_INTERACTION_TEST_MATRIX.md`.

---

## Observed issue D — the app draws fake macOS traffic lights

### Diagnosis

The UI appears to render red/yellow/green window buttons inside the content. This is acceptable for mockups, but wrong for an actual macOS app.

### Expected behavior

Use real NSWindow chrome. Web or SwiftUI content must not render fake traffic lights.

### Required fix

- Remove fake traffic-light elements from React/SVG mockup components.
- Use native `WindowGroup`/`NSWindow` titlebar and toolbar.
- If using a full-size content view, ensure titlebar traffic lights are provided by AppKit, not custom-drawn.

---

## Observed issue E — visual style is good, but empty states are not product-grade

### Expected empty states

- New chat: show a task launcher and suggested prompts, not a diff review screen.
- Review changes with no changes: show explanation and a button to start an agent turn.
- Settings with missing API key: show a clear setup state, not “healthy” plus “required” contradictions.
- Runtime unavailable: show start/retry diagnostics.

