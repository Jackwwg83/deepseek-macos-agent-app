# 06 — Performance Plan

## Product goal

The app should feel native and responsive on a typical Apple Silicon Mac.

## Performance budget

- First window visible: under 1.5 s in demo mode.
- Main screen route switch: under 150 ms perceived latency.
- Typing in composer: no visible lag; keystrokes should not trigger full app re-render.
- Runtime stream updates: batch to at most 10–20 UI updates per second.
- Scrolling thread timeline: smooth; avoid rendering thousands of event rows at once.
- Settings screen interactions: immediate state changes.

## Common causes of current lag

1. Full app re-renders on every runtime/SSE token.
2. Large backdrop blur/box-shadow effects over the full window.
3. Diff/code viewer rendered even when no file is selected.
4. WebView loads all routes/components eagerly.
5. State updates are stored at the root and fan out to every panel.
6. Heavy syntax highlighting runs synchronously on the main thread.
7. Images/icons/fonts are repeatedly loaded or not cached.

## Required optimizations if React/WebView remains

- Use route-level lazy loading.
- Virtualize long lists and thread timelines.
- Batch runtime/SSE events with `requestAnimationFrame` or 50–100 ms debounce.
- Store streamed token text in an isolated store/signal instead of global app state.
- Memoize card components.
- Lazy-load diff viewer only when review screen opens.
- Avoid Monaco unless needed; prefer CodeMirror 6 or a lightweight diff renderer.
- Disable large-area `backdrop-filter` and expensive animated gradients.
- Use CSS `contain: layout paint` for cards and panes where applicable.
- Keep only one scroll container per pane.

## Required optimizations if SwiftUI shell is adopted

- Keep high-frequency runtime events out of top-level `@State`.
- Use `ObservableObject`/`@Observable` models scoped per feature.
- Batch stream deltas before publishing to the view layer.
- Use stable `Identifiable` IDs for lists.
- Avoid rebuilding the entire `NavigationSplitView` on event updates.
- Move long-running work off the main actor.
- Instrument with Xcode’s responsiveness tools.

## Required tests

Codex must add at least one of:

- a debug overlay showing route render count and event batch frequency;
- a Playwright interaction test for the web surface;
- an XCTest launch/click test for the native shell;
- a simple performance smoke script that feeds 1,000 fake events and verifies the UI remains interactive.

## Acceptance checks

1. Typing in composer remains responsive while fake runtime streams events.
2. Opening Settings does not stutter.
3. Opening Review with no changes does not render code diff components.
4. Switching from Settings to New Thread is visually immediate.
5. Runtime stream is batched; no full-window re-render per token.

