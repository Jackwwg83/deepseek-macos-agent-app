# 03 — Keychain Prompt Removal

## Problem

The app currently triggers a macOS system dialog asking for the login keychain password. For an agent app, this feels alarming and should be treated as a release-blocking UX bug.

## Product rule

The app must never require the user to type the macOS login-keychain password in a system prompt during normal launch, settings load, or runtime startup.

## Likely technical causes

One or more of these is happening:

1. The app is using a Keychain access group or service name that conflicts with an item created by another binary/signing identity.
2. The item was created with an access control requiring user presence or prompting.
3. The app is reading the keychain item on startup before the user has opted into account setup.
4. The app changed code signing identity between builds, causing macOS to ask for access to an older keychain item.
5. The app is using a generic helper/library that requests interactive authentication on read.

## Implementation requirements

### Storage

Use a single generic password item:

```text
service: app.deepseek.agent
account: deepseek_api_key
label: DeepSeek API Key
accessible: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
synchronizable: false
```

Do not set access-control flags that require user presence for the API key in the MVP.

### Read behavior

- Read lazily when the user starts runtime or opens Settings.
- If read fails, do not invoke a system password prompt.
- Show an app-level state: “API key not available. Re-enter key.”

### Write behavior

- First run shows an in-app API key form.
- User clicks “Save key”.
- App stores key in Keychain.
- App immediately re-reads it to validate that silent access works.

### Rotation behavior

- “Rotate key” opens a native sheet with the old key masked.
- Saving replaces the Keychain item.
- Deleting removes the item and sets account status to “API key required”.

## Developer cleanup for testing

Codex should include a documented dev command or script:

```bash
security delete-generic-password -s app.deepseek.agent -a deepseek_api_key || true
```

Then launch the app and confirm no system keychain-password dialog appears.

## Acceptance tests

1. Clean keychain item, launch app: no system password prompt.
2. Enter API key in app form, save: no system prompt.
3. Relaunch app: key status is “Configured”; no system prompt.
4. Rotate key: no system prompt.
5. Delete key: app shows “API key required”; no system prompt.
6. If macOS still prompts, the build fails.

