# 09 — Acceptance Checklist

## Release-blocking fixes

- [ ] No macOS Keychain password prompt appears on launch.
- [ ] No macOS Keychain password prompt appears when opening Settings.
- [ ] API key setup uses an in-app sheet/form.
- [ ] App uses real macOS window chrome; no fake traffic lights inside content.
- [ ] No large blue/purple background bleed is visible inside the actual app window.
- [ ] New chat screen is not a blank review/diff screen.
- [ ] All visible buttons are either functional or clearly disabled with a reason.
- [ ] `Commit 0 files` cannot be clicked as an active primary action.
- [ ] Settings controls persist or are clearly demo-only.
- [ ] Demo mode works without a DeepSeek API key.
- [ ] Runtime mode clearly indicates whether API key is configured or required.
- [ ] UI remains responsive while fake runtime streams events.
- [ ] Codex has documented tests run and QA results.

## Visual acceptance

- [ ] Matches the target light, airy, Codex-inspired visual system.
- [ ] Sidebar, main content, and inspector align cleanly.
- [ ] Empty states are intentionally designed.
- [ ] Button hierarchy is clear.
- [ ] Destructive actions are not primary blue buttons.
- [ ] DeepSeek-only model names are used.
- [ ] No OpenAI/Codex model names appear in the DeepSeek app UI.

## Interaction acceptance

- [ ] New Thread creates a thread.
- [ ] Settings opens from gear and menu.
- [ ] Review Changes opens and handles no-change state.
- [ ] Model picker works.
- [ ] Toggles work.
- [ ] Rotate Key opens a sheet.
- [ ] Run Diagnostics shows result.
- [ ] Open in editor is disabled unless a file is selected.
- [ ] Apply/Reject are disabled when no files selected.
- [ ] Composer send button is disabled on empty prompt and active on non-empty prompt.

