# 08 — Native UI Implementation Notes

## Native shell target

Use native macOS components for all shell-level UI:

- `WindowGroup` / `NSWindow` for window chrome.
- `NavigationSplitView` for left navigation, main content, and inspector.
- Native `ToolbarItem`s for global actions.
- Native `Commands` for menus and keyboard shortcuts.
- Native sheets for setup, API key entry, diagnostics, and destructive confirmations.
- System `FileImporter` / `NSOpenPanel` for workspace folder selection.
- Keychain through Security framework.

## Suggested screen model

```swift
enum AppRoute: Hashable {
    case project(ProjectID)
    case thread(ThreadID)
    case review(ThreadID?)
    case settings
    case skills
    case automations
}

struct RuntimeStatus {
    var mode: RuntimeMode
    var sidecarVersion: String?
    var apiKeyStatus: APIKeyStatus
    var connection: ConnectionStatus
    var model: String
}
```

## WebView bridge if retained

The WebView should receive normalized UI state and emit explicit commands:

```ts
type AppCommand =
  | { type: 'startTurn'; threadId: string; prompt: string }
  | { type: 'selectFile'; path: string }
  | { type: 'review.applySelected'; paths: string[] }
  | { type: 'review.rejectSelected'; paths: string[] }
  | { type: 'settings.open' }
  | { type: 'runtime.diagnostics' };
```

Do not expose raw API keys or unrestricted shell commands to the WebView.

## Recommended first refactor

If the current app is fully web-rendered, do not rewrite everything at once.

1. Remove fake macOS chrome.
2. Fix root layout and blue background bleed.
3. Add interaction handlers and disabled states.
4. Fix keychain prompt.
5. Add tests.
6. Then move Settings and Sidebar to SwiftUI.

