# 04 — Layout and Visual Fix

## Objective

Keep the Codex-inspired light visual language, but make it production-native instead of screenshot/mockup-like.

## Visual system

- Background: neutral app surface inside the actual window.
- Sidebar: subtle macOS material or pale blue-tinted surface.
- Main: white or near-white content surface.
- Inspector: pale surface with cards.
- Borders: 1px low-contrast dividers.
- Corners: 10–16px for cards, native window corners from AppKit.
- Accent: restrained DeepSeek blue.
- Avoid large saturated gradient areas inside the live app.

## Required layout

```text
NSWindow content area
├─ Sidebar: 300–340 px
├─ Main content: flexible, min 640 px
└─ Inspector: 300–360 px, collapsible
```

Use native window chrome. Do not draw fake red/yellow/green controls.

## Main screen state rules

### When no thread has run yet

Show a starter canvas:

- title: “New chat”
- suggested prompts:
  - “Explain this project”
  - “Find risky changes”
  - “Write tests for this module”
  - “Plan a refactor”
- composer focused
- review panel says “No changes yet”
- no large blank diff area

### When agent is running

Show:

- plan/progress card;
- streamed reasoning summary if available;
- tool cards;
- terminal output;
- approval cards;
- stop button.

### When changes exist

Show:

- changed file summary;
- review queue;
- diff preview;
- apply/reject actions.

### When reviewing

Use the dedicated review layout from `references/target_mockups/04_review_changes_codex_inspired.png`.

## CSS/React requirements if WebView remains

- Root height must be exactly viewport height.
- No top-level marketing background in production.
- Use `minmax(0, 1fr)` for flexible grid columns to prevent overflow.
- Use `overflow: hidden` at shell level and scroll only in content panes.
- Use CSS variables from design tokens.
- Remove heavy `backdrop-filter` from large content areas; keep it only for sidebar or header if needed.

## Native requirements if SwiftUI shell is adopted

- Use `NavigationSplitView` for shell structure.
- Use `List(selection:)` or custom sidebar rows for projects/threads.
- Use `.toolbar` for New Thread, Runtime, Review, Settings actions.
- Use `.sheet` for API key setup and rotate-key flows.
- Use `.inspector` or a right split column for Review/Status panel.
- Use real `Commands` for app menus.

