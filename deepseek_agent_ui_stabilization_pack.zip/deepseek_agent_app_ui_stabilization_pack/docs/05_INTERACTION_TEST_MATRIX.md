# 05 — Interaction Test Matrix

Codex must implement automated or documented manual checks for every row.

## Navigation

| Control | Initial state | Expected result |
|---|---|---|
| New thread | Always enabled | Creates a new empty thread and focuses composer |
| Recent thread row | Enabled when row exists | Loads selected thread |
| Project row | Enabled | Opens Project Command Center |
| Automations | Enabled or hidden | Opens Automations page or shows “Coming soon” |
| Skills | Enabled or hidden | Opens Skills page or shows “Coming soon” |
| Settings gear | Enabled | Opens Settings & Usage |
| Review changes | Enabled only if changes exist; otherwise opens empty review | Shows review screen with clear empty state |

## Composer

| Control | Expected result |
|---|---|
| Text input | Typing works without lag |
| Send button with empty input | Disabled |
| Send button with text | Starts fake/runtime turn |
| Enter | Sends message |
| Shift+Enter | Inserts newline |
| Model picker | Opens DeepSeek-only model list |
| Attachment icon | Opens file picker or shows disabled reason |

## Review actions

| Control | Empty state | With changes |
|---|---|---|
| Open in editor | Disabled with reason | Opens selected file in configured editor |
| Apply selected | Disabled | Applies selected files |
| Reject selected | Disabled | Reverts selected files |
| Request more tests | Disabled if runtime unavailable | Sends follow-up test request |
| Commit N files | Disabled when N=0 | Commits or stages selected files depending MVP scope |

## Settings

| Control | Expected result |
|---|---|
| Manage account | Opens account sheet |
| Rotate key | Opens API key sheet |
| Model dropdown | Persists selected DeepSeek model |
| Temperature field | Persists valid value, rejects invalid |
| Reasoning effort | Persists selected value |
| Toggle controls | Visually update and persist |
| Accent color | Updates UI token or persists selection |
| Run diagnostics | Runs sidecar/API diagnostic and displays result |

## Keychain

| Scenario | Expected result |
|---|---|
| No key stored | In-app setup state; no system password dialog |
| Key stored | “Configured” status; no system password dialog |
| Rotate key | In-app sheet; no system password dialog |
| Delete key | “Required” status; no system password dialog |

## Empty states

| Screen | Expected state |
|---|---|
| New chat | Starter prompts, composer, no diff review blank area |
| Review changes, no changes | “No changes yet” with “Start an agent turn” guidance |
| Settings, missing API key | clear required state and setup CTA |
| Runtime unavailable | retry/start diagnostics |

