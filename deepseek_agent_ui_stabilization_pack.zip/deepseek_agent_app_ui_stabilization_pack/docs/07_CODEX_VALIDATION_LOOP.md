# 07 — Codex Validation Loop

## Why this matters

The previous iteration likely optimized for screenshot appearance instead of runtime behavior. Codex must be instructed to work like a QA-driven engineer, not a static mockup generator.

## Required `/goal` loop

In each iteration Codex must:

1. Inspect current implementation and identify shell architecture.
2. Make the smallest coherent change.
3. Build the app.
4. Run unit tests and interaction tests.
5. Launch demo mode or fake runtime mode.
6. Capture or describe screenshots for the affected screens.
7. Update a progress log with:
   - changed files;
   - tests run;
   - manual checks;
   - known remaining issues;
   - next step.
8. Continue until all acceptance checks pass or stop with a precise blocker.

## Stop conditions

Codex may stop only if:

- the app builds and all acceptance checks pass; or
- a specific blocker prevents progress, with exact command output and file references.

It must not stop after only matching visual layout.

## Required files Codex should create or update

```text
docs/IMPLEMENTATION_PROGRESS.md
docs/UI_QA_RESULTS.md
docs/KNOWN_ISSUES.md
```

## Required commands

Codex must discover actual project commands. If unavailable, it must create or document minimal commands such as:

```bash
npm run build
npm run test
npm run test:e2e
xcodebuild -scheme DeepSeekAgent -configuration Debug build
xcodebuild test -scheme DeepSeekAgent -configuration Debug
```

Do not fake successful test output.

## Recommended Codex invocation

```text
/goal Implement docs/CODEX_UI_STABILIZATION_GOAL.md. Keep iterating until the macOS app launches, no Keychain password prompt appears, demo mode works, all visible controls have active or explicitly disabled behavior, no blue background bleed remains inside the window, and all documented QA checks pass.
```

