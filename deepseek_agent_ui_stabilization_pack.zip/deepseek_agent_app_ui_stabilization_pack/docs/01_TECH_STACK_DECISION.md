# 01 — Frontend Technology Decision

## Decision

For a macOS-only product, the recommended stack is **native SwiftUI/AppKit shell + optional WKWebView content surface**, not a full React/Electron-style UI.

The app should be structured as:

```text
DeepSeek Agent.app
├─ Native macOS shell
│  ├─ real NSWindow chrome and toolbar
│  ├─ NavigationSplitView sidebar
│  ├─ Settings and onboarding in SwiftUI
│  ├─ Keychain, file picker, menus, shortcuts
│  ├─ sidecar process manager
│  └─ runtime status model
│
├─ Optional Web content surface
│  ├─ Active thread timeline
│  ├─ review/diff viewer
│  ├─ terminal output card
│  └─ markdown rendering
│
└─ DeepSeek-TUI sidecar
   └─ HTTP/SSE runtime API
```

## Why not full web UI?

A full React/WebView UI can look good quickly, but the current prototype shows typical failure modes:

- fake macOS traffic lights and fake titlebar inside the page;
- CSS gradient/blur leaking into the actual application layout;
- click targets that look native but are not wired to native state;
- re-rendering too much on streamed runtime events;
- unclear ownership between native keychain/window behavior and web state.

## Why native shell?

Native SwiftUI/AppKit gives better control over:

- macOS window chrome, menus, toolbars, keyboard shortcuts, focus rings, and accessibility;
- Keychain and secure storage flows;
- sidecar process lifecycle and local file access;
- settings/onboarding interactions;
- performance instrumentation through Xcode/Instruments;
- system-native controls such as toggles, segmented controls, split views, sheets, and file dialogs.

## What should remain web-based?

A WKWebView/React surface is still acceptable for areas where web tooling is strong:

- large markdown/thread timeline;
- diff viewer;
- syntax highlighting;
- terminal output;
- rich code review cards.

But the WebView must be treated as a content view, not as the whole app shell.

## Migration path

### Stage 1 — stabilize current UI

Keep the current implementation but fix:

- keychain prompt;
- blue background bleed;
- non-clickable controls;
- fake macOS chrome;
- untested empty states;
- lag from unnecessary re-renders.

### Stage 2 — native shell extraction

Move these from web to SwiftUI/AppKit:

- window titlebar/toolbar;
- sidebar;
- settings;
- onboarding;
- account/runtime status panels;
- menus and keyboard shortcuts;
- sidecar manager.

### Stage 3 — WebView as thread/review renderer

Keep or rebuild the active thread and review panes as WebView content only if it remains performant.

## Required Codex behavior

Codex must not simply update CSS until a screenshot looks right. It must build and test interactions:

- every visible button has a handler or explicit disabled state;
- no fake titlebar or fake traffic lights inside app content;
- no Keychain password dialog on first launch or normal launch;
- main window renders without visible blue background bleed inside the content area;
- demo mode works without a DeepSeek API key;
- real runtime mode can be smoke-tested with a local sidecar when available.
