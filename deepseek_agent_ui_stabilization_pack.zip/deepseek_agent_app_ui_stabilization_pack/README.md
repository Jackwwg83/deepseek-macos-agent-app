# DeepSeek Agent macOS UI Stabilization Pack

This pack is a corrective UI/UX and engineering brief for the current DeepSeek Agent macOS prototype.
It is intended to be dropped into the app repository and used with Codex `/goal`.

## Purpose

The current prototype visually approximates the target mockups, but it has product and implementation failures:

1. A confusing macOS Keychain password prompt appears on launch.
2. A large blue/purple background area leaks inside the app window.
3. Several controls look clickable but are not wired or have unclear disabled states.
4. The app appears to draw fake macOS window chrome inside content.
5. The UI is visually close but feels laggy.
6. Codex likely only matched screenshots and did not execute a sufficient interaction/performance test loop.

## Recommended architecture

Use a macOS-native hybrid:

- Native SwiftUI/AppKit shell for the real window, sidebar, settings, onboarding, menus, keychain, file picker, sidecar lifecycle, and global state.
- Optional WKWebView/React only for dense thread/diff/terminal rendering if needed.
- DeepSeek-TUI remains the runtime sidecar. Do not reimplement the runtime.

## Main files

- `codex/CODEX_UI_STABILIZATION_GOAL.md` — paste this into Codex `/goal`.
- `codex/AGENTS_UI_QA.md` — add/merge into project `AGENTS.md`.
- `docs/01_TECH_STACK_DECISION.md` — recommended frontend choice.
- `docs/02_BUGFIX_SPEC.md` — concrete fixes for the screenshots.
- `docs/03_KEYCHAIN_FIX.md` — keychain prompt removal.
- `docs/04_LAYOUT_AND_VISUAL_FIX.md` — layout, blue background, and native chrome fixes.
- `docs/05_INTERACTION_TEST_MATRIX.md` — required click and navigation tests.
- `docs/06_PERFORMANCE_PLAN.md` — lag diagnosis and performance budgets.
- `docs/07_CODEX_VALIDATION_LOOP.md` — how Codex must iterate.
- `docs/08_NATIVE_UI_IMPLEMENTATION_NOTES.md` — SwiftUI/AppKit implementation guidance.
- `docs/09_ACCEPTANCE_CHECKLIST.md` — final release gate.

