# Package Manifest

- README.md
- index.html
- codex/CODEX_UI_STABILIZATION_GOAL.md
- codex/AGENTS_UI_QA.md
- docs/01_TECH_STACK_DECISION.md
- docs/02_BUGFIX_SPEC.md
- docs/03_KEYCHAIN_FIX.md
- docs/04_LAYOUT_AND_VISUAL_FIX.md
- docs/05_INTERACTION_TEST_MATRIX.md
- docs/06_PERFORMANCE_PLAN.md
- docs/07_CODEX_VALIDATION_LOOP.md
- docs/08_NATIVE_UI_IMPLEMENTATION_NOTES.md
- docs/09_ACCEPTANCE_CHECKLIST.md
- references/observed/*.png
- references/target_mockups/*.png
